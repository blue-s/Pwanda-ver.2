#include <stdio.h>
typedef unsigned char uchar;
uchar ucaExt[];