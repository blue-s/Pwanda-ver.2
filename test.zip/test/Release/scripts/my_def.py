def PrintMyDef():
	print "Hello, MyDef!"

def Multiply(x, y):
	print type(x*y)
	return x * y

print Multiply(3,4)