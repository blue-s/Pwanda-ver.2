def PrintMyDef():
	print "Hello, MyDef!"

def Multiply(x, y):
	return x*y